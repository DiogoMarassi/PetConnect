from django.apps import AppConfig


class petconnectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'petconnect'
