from django.contrib import admin
from .models import Pet

admin.site.register(Pet)
