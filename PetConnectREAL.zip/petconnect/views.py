from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_POST
from django.contrib.auth.models import User
from django.contrib import messages
from .models import Pet
from django import forms

#Esta função obtém todas as tarefas do models Task (que nós criamos em models.py) usando Task.objects.all(). As tarefas são armazenadas em um "context", com a chave "tasks". Em seguida, a função renderiza o template list_tasks.html, passando o contexto.
'''
def list_tasks(request):
    tasks = Task.objects.all()
    context = {"tasks": tasks}
    return render(request, "list_tasks.html", context=context)
'''

#Esta função lida com a criação de uma nova tarefa. Se o método da requisição for POST, isso significa que o formulário foi enviado. Em seguida, a função redireciona o usuário para a página de tarefas. Caso contrário, se o método da requisição não for POST, a função renderiza o template task_form.html, que contém o formulário para criar uma nova tarefa.
'''
def create_task(request):
    # Se o usuário submeter o formulário, ele cai no if abaixo
    if request.method == "POST":
        Task.objects.create(title=request.POST["title"],
                            description=request.POST["description"],
                            due_date=request.POST["due-date"],
                            done=False)
        return redirect("tasks-list")
    return render(request, "task_form.html")
'''

#Esta função lida com a atualização de uma tarefa existente. Ela obtém a tarefa correspondente ao task_id fornecido usando Task.objects.get(). Em seguida, se o método da requisição for POST, a função atualiza os campos da tarefa com os dados fornecidos no formulário e salva as alterações no banco de dados. Caso contrário, se o método da requisição não for POST, a função renderiza o template task_form.html com a tarefa atualizada como contexto.
'''
def update_task(request, task_id):
    task = Task.objects.get(id=task_id)
    task.due_date = task.due_date.strftime('%Y-%m-%d')

    if request.method == "POST":
        task.title = request.POST["title"]
        task.description = request.POST["description"]
        task.due_date = request.POST["due-date"]
        if "done" not in request.POST:
            task.done = False
        else:
            task.done = True
        task.save()
        return redirect("tasks-list")

    return render(request, "task_form.html", context={"task": task})
'''

# Esta função lida com a exclusão de uma tarefa. Ela obtém a tarefa correspondente ao task_id fornecido usando Task.objects.get(). Se o método for POST e a chave "confirm" estiver presente nos dados da requisição, a tarefa é excluída. Em seguida, a função redireciona o usuário para a página de listagem de tarefas. Caso contrário, se o método GET (não post) ou a chave "confirm" não estiver presente, a função renderiza o template delete_form.html com a tarefa a ser excluída como contexto.
'''
def delete_task(request, task_id):
    task = Task.objects.get(id=task_id)
    if request.method == "POST":
        if "confirm" in request.POST:
            task.delete()

        return redirect("tasks-list")

    return render(request, "delete_form.html", context={"task": task})
'''

#============================================================================================
#============================================================================================

#Função responsável apenas por renderizar a página inicial home.html. Utiliza o atalho render do django para realizar essa tarefa.


def home(request):
    users = User.objects.all()
    return render(request, 'home.html', {'users': users})

def pagina1(request):
    return render(request, "pagina1.html")


def pagina2(request):
    return render(request, "pagina2.html")


#Remderiza a página do login
def paginaLogin(request):
    return render(request, "registration/login.html")


def paginaLogin_erro(request):
    return render(request, "registration/login-erro.html")


def cadastro(request):
    return render(request, "cadastro.html")


def paginapets(request):
    pets = Pet.objects.all()
    context = {"pets": pets}
    return render(request, "meuspets.html", context = context)


#Função para efetuar o cadastro e verificar se o email ou nome de usuario ja existem
def efetuarCadastro(request):
    #Verifica se o método usado é o POST
    if request.method == 'POST':
        # Verifica se os campos necessários estão presentes
        if 'nome' in request.POST and 'email' in request.POST and 'password' in request.POST:
            nome_usuario = request.POST['nome']
            email_usuario = request.POST['email']
            senha_usuario = request.POST['password']

            # Verifica se o nome de usuário ou email já existem
            if User.objects.filter(username=nome_usuario).exists():
                #Se já existir, retorna a mesma página de cadastro e improme a mensagem de erro
                messages.error(
                    request, 'Nome de usuário já existe, tente fazer login.')
                return redirect('paginaLogin-erro')
            elif User.objects.filter(email=email_usuario).exists():
                messages.error(request,
                               'Email já está em uso, tente fazer login.')
                return redirect('paginaLogin-erro')
            #Se for um novo usário real, o cadastro é concluido e redireciona para a página de login
            else:
                novoUsuario = User.objects.create_user(username=nome_usuario,
                                                       email=email_usuario,
                                                       password=senha_usuario)
                novoUsuario.save()
                messages.success(request, 'Conta criada com sucesso!')
                return redirect('login')

        else:
            messages.error(request, 'Todos os campos são obrigatórios.')
            return redirect('cadastro')

    else:
        return render(request, 'cadastro.html')


#Rnderiza a página do abrigo1
def abrigo1(request):
    return render(request, "abrigo1.html")


#Renderiza a página do abrigo2
def abrigo2(request):
    return render(request, "abrigo2.html")


#Renderiza a página do abrigo3
def abrigo3(request):

    return render(request, "abrigo3.html")


def add_Pet(request):
    # Se o usuário submeter o formulário, ele cai no if abaixo
    if request.method == "POST":
        Pet.objects.create(nome=request.POST["nome"],
                           raca=request.POST["raca"],
                           porte=request.POST["porte"],
                           localizacao=request.POST["localizacao"],
                           historia=request.POST["historia"],
                           personalidade=request.POST["personalidade"])
        return redirect("meuspets")
      
    return render(request, "adicionarPets.html")


'''
#Serve para adicionar um pet no perfil do abrigo
class PetForm(forms.ModelForm):
    class Meta:
        model = Pet
        fields = [
            'nome', 'raca', 'porte', 'localizacao', 'historia',
            'personalidade', 'picture'
        ]


def add_Pet(request):
    if request.method == "POST":
        form = PetForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = PetForm()
    return render(request, 'adicionarPets.html', {'form': form})

 '''


#Serve para editar um pet no perfil do abrigo
def editar_Pet(request, pet_id):
    pet = Pet.objects.get(id=pet_id)

    if request.method == "POST":
        pet.nome = request.POST["nome"],
        pet.raca = request.POST["raca"],
        pet.porte = request.POST["porte"],
        pet.localizacao = request.POST["localizacao"],
        pet.historia = request.POST["historia"],
        pet.personalidade = request.POST["personalidade"]
        pet.save()
        return redirect("meuspets")

    return render(request, "adicionarPets.html", context={"pet": pet})


#Serve para deletar um pet no perfil do abrigo
def delete_Pet(request, pet_id):
    pet = Pet.objects.get(id=pet_id)
    if request.method == "POST":
        if "confirm" in request.POST:
            pet.delete()
        return redirect("meuspets")

    return render(request, "delete_pet.html", context={"pet": pet})
