# models.py define a estrutura do modelo de dados para a entidade Task no aplicativo.

#1-A primeira linha importa o módulo models do Django, que contém as classes necessárias para definir um modelo de dados.

#class Task(models.Model): Esta linha cria uma classe 'Task', que herda da classe models.Model. Isso indica que a classe Task é um modelo de dados que será mapeado para uma tabela no banco de dados.

#title = models.CharField(max_length=50): Esta linha define um espaço de caracteres (CharField) chamado 'title' para armazenar o título da tarefa. O argumento max_length define o comprimento máximo do campo.

#description = models.TextField(): Esta linha define um espaço amplo (TextField) chamado 'description' para armazenar a descrição da tarefa.

#due_date = models.DateField(): Esta linha define o campo para data limite da tarefa.

#done = models.BooleanField(): Esta linha define um campo booleano (true ou false) chamado 'done' para indicar se a tarefa foi concluída ou não.

from django.db import models

class Pet(models.Model):
  nome = models.CharField(max_length=30)
  raca = models.CharField(max_length=30)
  idade = models.CharField(max_length=30)
  porte = models.CharField(max_length=30)
  localizacao = models.CharField(max_length=30)
  historia = models.CharField(max_length=30)
  personalidade = models.CharField(max_length=30)

  

#MODELS: objetos python que representam uma tabela no banco de dados
# 1) models -> 2) transf. codigo SQL -> 3) irá criar essas tabelas no banco de dados
#2) Rodar um código que transformará minhas classes em python em codigo SQL
#Usuarios vai herdar da classe models.Model
