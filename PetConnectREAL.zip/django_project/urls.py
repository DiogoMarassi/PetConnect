"""django_project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

# urls.py define as rotas (URLs) do aplicativo. Cada rota é associada a uma função que será executada quando a rota correspondente for acessada. A função é responsável por processar a requisição HTTP e retornar uma resposta, como renderizar um template ou redirecionar para outra página.

# O import path é usada para definir rotas.

# from appdodiogo import views importa o módulo views

# urlpatterns: Essa variável é uma lista que contém as rotas do aplicativo.

#path('admin/', admin.site.urls): Esta rota é responsável por mapear a URL http://seu-dominio.com/admin/ para o painel de administração do Django. Ela usa a função admin.site.urls para configurar as URLs do painel de administração.

#path('', views.home): Esta rota mapeia a URL principal do app para a função chamada views.home, que renderiza a página inicial do aplicativo.

#path('tasks/', views.list_tasks, name="tasks-list"): Mapeia URL/tasks para a função views.list_tasks, que é responsável por exibir a lista de tarefas. O argumento name="tasks-list" é um nome de referência que pode ser usado para criar links e referenciar essa rota em outros lugares do código.

#path('tasks/create/', views.create_task): Faz a mesma coisa que a anterior, para uma diferente URL e função de visualização.

#path('tasks/edit/<task_id>', views.update_task): O parâmetro <task_id> captura o identificador da tarefa e passa para a função de visualização como um argumento.

from django.contrib import admin
from django.urls import path, include
from petconnect import views
from django.conf import settings
from django.conf.urls.static import static

# rota, view responsável (função), nome de referencia
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('abrigo1/', views.abrigo1, name='abrigo1'),
    path('abrigo2/', views.abrigo2, name='abrigo2'),
    path('abrigo3/', views.abrigo3, name='abrigo3'),
    path('pagina1/', views.pagina1, name='pagina1'),
    path('pagina2/', views.pagina2, name='pagina2'),
    path('cadastro/', views.efetuarCadastro, name='cadastro'),
    path('login/', views.paginaLogin, name='paginaLogin'),
    path('login-erro/', views.paginaLogin_erro, name='paginaLogin-erro'),
    path('meuspets/', views.paginapets, name='meuspets'),
    path('adicionarPets/', views.add_Pet, name='add_Pet'),
    path('pet/edit/<pet_id>', views.editar_Pet),
    path('pet/delete/<pet_id>', views.delete_Pet),
    path(
        'accounts/', include('django.contrib.auth.urls')
    ),  # O django usa o accounts como padrão. Nós importamos todas as URL's "accounts / alguma coisa" do django
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
